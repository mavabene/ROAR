class AgentException(Exception):
    pass
